/**
 * VegaMind Widget — Enterprise Plan
 * ─────────────────────────────────────────────────────────────
 * Themes:   All Pro themes + custom
 * Branding: Hidden by default
 * Options:  Everything in Pro, plus:
 *           avatarUrl  — custom image URL for bot avatar
 *           customCSS  — inject raw CSS string for full override
 *
 * EMBED:
 *   <script>
 *     window.VegaMindConfig = {
 *       widgetKey:  'your-key-here',
 *       theme:      'qbs',
 *       avatarUrl:  'https://yoursite.com/bot-avatar.png',
 *       customCSS:  '#vm-header { border-bottom: 2px solid gold; }',
 *     };
 *   </script>
 *   <script src="https://qbsglobal.ae/widget/loader-enterprise.js" async></script>
 */
(function () {
  'use strict';
  if (window.__VegaMindLoaded) return;
  window.__VegaMindLoaded = true;

  var ALLOWED = ['minimal', 'bold', 'dark', 'soft', 'qbs', 'custom'];

  var scriptEl = document.currentScript || document.querySelector('script[data-key]');
  var da = {};
  if (scriptEl) {
    if (scriptEl.dataset.key)      da.widgetKey   = scriptEl.dataset.key;
    if (scriptEl.dataset.name)     da.botName     = scriptEl.dataset.name;
    if (scriptEl.dataset.color)    da.accentColor = scriptEl.dataset.color;
    if (scriptEl.dataset.header)   da.headerColor = scriptEl.dataset.header;
    if (scriptEl.dataset.theme)    da.theme       = scriptEl.dataset.theme;
    if (scriptEl.dataset.position) da.position    = scriptEl.dataset.position;
  }

  var cfg = Object.assign({
    widgetKey: '', theme: 'minimal', botName: '', placeholder: 'How can I help you today?',
    position: 'bottom-right', bubbleSize: '58px', zIndex: '9999', poweredBy: false,
    accentColor: null, headerColor: null, userBubbleColor: null, botBubbleColor: null,
    fontFamily: null, borderRadius: null, bubbleColor: null,
    panelWidth: '380px', panelHeight: '560px', avatarEmoji: null,
    avatarUrl: null, customCSS: '', openOnLoad: false,
  }, da, window.VegaMindConfig || {});

  if (!cfg.widgetKey) { console.warn('[VegaMind Enterprise] widgetKey missing'); return; }
  if (ALLOWED.indexOf(cfg.theme) === -1) { cfg.theme = 'minimal'; }
  if (cfg.customCSS && cfg.customCSS.indexOf('<script') !== -1) { cfg.customCSS = ''; }

  function loadCore() {
    if (window.__VegaMindCore) { window.__VegaMindCore(cfg, 'enterprise'); }
    else { setTimeout(loadCore, 50); }
  }

  var cs = document.createElement('script');
  cs.src = 'https://qbsglobal.ae/widget/widget-core.js';
  cs.onload = loadCore;
  document.head.appendChild(cs);
})();

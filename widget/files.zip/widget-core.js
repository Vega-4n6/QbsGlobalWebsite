// VegaMind Widget Core Engine v2.0
// Shared by loader.js / loader-pro.js / loader-enterprise.js
window.__VegaMindCore = function (cfg, PLAN) {
  var SUPABASE_FN   = 'https://lyiqesxemmisigccslfn.supabase.co/functions/v1';
  var SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx5aXFlc3hlbW1pc2lnY2NzbGZuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2NTQwNzgsImV4cCI6MjA4ODIzMDA3OH0.QIdGOfuIm4om3nrWBnBb02slLrZLSbN9fuNiKkDgJ9s';
  var sessionId=null, isOpen=false, isTyping=false;
  function gvid(){try{var id=localStorage.getItem('_vm_vid');if(!id){id='v_'+Math.random().toString(36).slice(2)+Date.now().toString(36);localStorage.setItem('_vm_vid',id)}return id}catch(e){return 'v_'+Math.random().toString(36).slice(2)}}
  var visitorId=gvid();

  // ── Themes ──
  var THEMES={
    minimal:{headerBg:'#1B4F72',headerText:'#fff',accentColor:'#2ECC71',userBubbleBg:'#1B4F72',userBubbleText:'#fff',botBubbleBg:'#fff',botBubbleText:'#1e1e2e',panelBg:'#f2f3f5',inputBg:'#fafafa',inputBorder:'#e4e4e7',inputText:'#18181b',poweredBg:'#fff',bubbleBg:'#1B4F72',font:'-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif',borderRadius:'18px'},
    bold:{headerBg:'linear-gradient(135deg,#0f0f0f,#1a1a2e)',headerText:'#fff',accentColor:'#00D4FF',userBubbleBg:'#00D4FF',userBubbleText:'#0f0f0f',botBubbleBg:'#1e1e2e',botBubbleText:'#e0e0e0',panelBg:'#141420',inputBg:'#1e1e2e',inputBorder:'#333',inputText:'#fff',poweredBg:'#0f0f0f',bubbleBg:'linear-gradient(135deg,#00D4FF,#0088ff)',font:'"Segoe UI",system-ui,sans-serif',borderRadius:'14px'},
    dark:{headerBg:'#1a1a1a',headerText:'#fff',accentColor:'#7C3AED',userBubbleBg:'#7C3AED',userBubbleText:'#fff',botBubbleBg:'#2a2a2a',botBubbleText:'#e8e8e8',panelBg:'#222',inputBg:'#2a2a2a',inputBorder:'#3a3a3a',inputText:'#fff',poweredBg:'#1a1a1a',bubbleBg:'#7C3AED',font:'-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',borderRadius:'16px'},
    qbs:{headerBg:'linear-gradient(135deg,#0a0a0a,#111827)',headerText:'#fff',accentColor:'#10B981',userBubbleBg:'#10B981',userBubbleText:'#fff',botBubbleBg:'#1f2937',botBubbleText:'#f3f4f6',panelBg:'#111827',inputBg:'#1f2937',inputBorder:'#374151',inputText:'#f9fafb',poweredBg:'#0a0a0a',bubbleBg:'linear-gradient(135deg,#10B981,#059669)',font:'"Segoe UI",system-ui,sans-serif',borderRadius:'12px'},
    soft:{headerBg:'linear-gradient(135deg,#667eea,#764ba2)',headerText:'#fff',accentColor:'#F093FB',userBubbleBg:'linear-gradient(135deg,#667eea,#764ba2)',userBubbleText:'#fff',botBubbleBg:'#fff',botBubbleText:'#4a4a68',panelBg:'#f5f3fa',inputBg:'#fff',inputBorder:'#e8e0f0',inputText:'#4a4a68',poweredBg:'#fff',bubbleBg:'linear-gradient(135deg,#667eea,#764ba2)',font:'Georgia,"Times New Roman",serif',borderRadius:'20px'},
  };

  var themeName=(PLAN==='starter')?'minimal':(cfg.theme||'minimal');
  var base=THEMES[themeName]||THEMES.minimal;
  var T;
  if(PLAN==='starter'){
    T=Object.assign({},base,{headerBg:cfg.headerColor||cfg.accentColor||base.headerBg,accentColor:cfg.accentColor||base.accentColor,userBubbleBg:cfg.headerColor||cfg.accentColor||base.userBubbleBg,bubbleBg:cfg.headerColor||cfg.accentColor||base.bubbleBg});
  } else {
    T=Object.assign({},base,{headerBg:cfg.headerColor||base.headerBg,accentColor:cfg.accentColor||base.accentColor,userBubbleBg:cfg.userBubbleColor||base.userBubbleBg,botBubbleBg:cfg.botBubbleColor||base.botBubbleBg,font:cfg.fontFamily||base.font,borderRadius:cfg.borderRadius||base.borderRadius,bubbleBg:cfg.bubbleColor||base.bubbleBg});
  }

  var customCSS=(PLAN==='enterprise'&&cfg.customCSS)?cfg.customCSS:'';
  var showPowered=PLAN==='starter'?true:PLAN==='pro'?(cfg.poweredBy!==false):false;
  var avatarContent=(PLAN==='enterprise'&&cfg.avatarUrl)?'<img src="'+cfg.avatarUrl+'" style="width:100%;height:100%;object-fit:cover;border-radius:50%" alt="Bot">':'\u{1F916}';
  var botName=cfg.botName||'Assistant';
  var placeholder=cfg.placeholder||'Type a message\u2026';
  var bubbleSize=cfg.bubbleSize||'58px';
  var zIndex=cfg.zIndex||'9999';
  var isLeft=cfg.position==='bottom-left';
  var pos=isLeft?'bottom:24px;left:24px;':'bottom:24px;right:24px;';
  var origin=isLeft?'bottom left':'bottom right';
  var align=isLeft?'align-items:flex-start;':'align-items:flex-end;';
  var dk=['bold','dark','qbs'].indexOf(themeName)!==-1;
  var bb=dk?'border:1px solid rgba(255,255,255,.08);':'border:1px solid #ededf0;';
  var bs=dk?'box-shadow:0 2px 6px rgba(0,0,0,.2);':'box-shadow:0 2px 8px rgba(0,0,0,.06);';

  // ── Markdown ──
  function md(t){if(!t)return '';var h=t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');h=h.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');h=h.replace(/__(.+?)__/g,'<strong>$1</strong>');h=h.replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g,'<em>$1</em>');h=h.replace(/`(.+?)`/g,'<code class="vm-c">$1</code>');h=h.replace(/\[(.+?)\]\((.+?)\)/g,'<a href="$2" target="_blank" rel="noopener" class="vm-a">$1</a>');h=h.replace(/\n/g,'<br>');h=h.replace(/((?:(?:^|<br>)\s*[\-\*\u2022]\s+.+)+)/g,function(m){var i=m.split('<br>').filter(function(l){return l.trim()}).map(function(l){return '<li>'+l.replace(/^\s*[\-\*\u2022]\s+/,'')+'</li>'}).join('');return '<ul class="vm-l">'+i+'</ul>'});h=h.replace(/((?:(?:^|<br>)\s*\d+[\.\)]\s+.+)+)/g,function(m){var i=m.split('<br>').filter(function(l){return l.trim()}).map(function(l){return '<li>'+l.replace(/^\s*\d+[\.\)]\s+/,'')+'</li>'}).join('');return '<ol class="vm-l">'+i+'</ol>'});return h}

  function injectStyles(){
    var s=document.createElement('style');s.setAttribute('data-vm','1');
    s.textContent=`
#vm-root,#vm-root *,#vm-root *::before,#vm-root *::after{box-sizing:border-box;margin:0;padding:0;-webkit-font-smoothing:antialiased}
#vm-root{position:fixed;${pos}z-index:${zIndex};font-family:${T.font};font-size:14px;line-height:1.5;display:flex;flex-direction:column;${align}gap:14px}
#vm-panel{width:${cfg.panelWidth||'380px'};height:${cfg.panelHeight||'560px'};max-height:calc(100vh - 120px);background:${T.panelBg};border-radius:${T.borderRadius};box-shadow:0 12px 48px rgba(0,0,0,.18),0 2px 8px rgba(0,0,0,.08);display:flex;flex-direction:column;overflow:hidden;transform:scale(.92) translateY(14px);opacity:0;pointer-events:none;transition:transform .28s cubic-bezier(.34,1.56,.64,1),opacity .2s ease;transform-origin:${origin}}
#vm-panel.vm-open{transform:scale(1) translateY(0);opacity:1;pointer-events:all}
#vm-header{background:${T.headerBg};padding:16px 18px;display:flex;align-items:center;gap:12px;flex-shrink:0}
#vm-av{width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;border:2px solid rgba(255,255,255,.2);overflow:hidden}
#vm-hi{flex:1;min-width:0}
#vm-hn{color:${T.headerText};font-size:15px;font-weight:600;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#vm-hs{color:rgba(255,255,255,.75);font-size:11.5px;display:flex;align-items:center;gap:5px;margin-top:2px}
.vm-d{width:7px;height:7px;border-radius:50%;background:#4ade80;display:inline-block;animation:vm-p 2.5s ease infinite}
@keyframes vm-p{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(.85)}}
#vm-xb{background:rgba(255,255,255,.1);border:none;cursor:pointer;color:rgba(255,255,255,.8);width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;transition:background .15s,color .15s;flex-shrink:0;margin-left:auto}
#vm-xb:hover{background:rgba(255,255,255,.2);color:#fff}
#vm-ms{flex:1;overflow-y:auto;padding:18px 14px;display:flex;flex-direction:column;gap:10px;min-height:0;background:${T.panelBg};scroll-behavior:smooth}
#vm-ms::-webkit-scrollbar{width:4px}
#vm-ms::-webkit-scrollbar-track{background:transparent}
#vm-ms::-webkit-scrollbar-thumb{background:${dk?'rgba(255,255,255,.15)':'#d4d4d8'};border-radius:4px}
.vm-m{max-width:78%;padding:11px 15px;font-size:13.5px;line-height:1.6;word-break:break-word;animation:vm-fi .22s ease}
@keyframes vm-fi{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.vm-u{background:${T.userBubbleBg};color:${T.userBubbleText};align-self:flex-end;border-radius:${T.borderRadius} ${T.borderRadius} 4px ${T.borderRadius};padding:11px 16px;box-shadow:0 2px 8px rgba(0,0,0,.1)}
.vm-b{background:${T.botBubbleBg};color:${T.botBubbleText};align-self:flex-start;border-radius:4px ${T.borderRadius} ${T.borderRadius} ${T.borderRadius};${bb}${bs}}
.vm-b strong{font-weight:600}
.vm-b em{font-style:italic;opacity:.85}
.vm-b .vm-c{background:${dk?'rgba(255,255,255,.08)':'rgba(0,0,0,.06)'};padding:1px 5px;border-radius:3px;font-size:12px;font-family:'SFMono-Regular',Consolas,monospace}
.vm-b .vm-a{color:${T.accentColor};text-decoration:underline;text-underline-offset:2px}
.vm-b .vm-l{margin:6px 0;padding-left:20px}
.vm-b .vm-l li{margin:3px 0;padding-left:2px}
.vm-t{background:${T.botBubbleBg};align-self:flex-start;border-radius:4px ${T.borderRadius} ${T.borderRadius} ${T.borderRadius};${bb}${bs}padding:13px 20px;display:flex;gap:5px;align-items:center}
.vm-t span{display:block;width:7px;height:7px;background:${T.accentColor};border-radius:50%;opacity:.4;animation:vm-bn 1.4s infinite}
.vm-t span:nth-child(2){animation-delay:.15s}
.vm-t span:nth-child(3){animation-delay:.3s}
@keyframes vm-bn{0%,60%,100%{transform:translateY(0);opacity:.35}30%{transform:translateY(-5px);opacity:1}}
#vm-ir{display:flex;align-items:center;gap:10px;padding:14px 16px;background:${T.poweredBg};border-top:1px solid ${T.inputBorder};flex-shrink:0}
#vm-in{flex:1;border:1.5px solid ${T.inputBorder};border-radius:24px;padding:10px 16px;font-size:13.5px;font-family:${T.font};outline:none;background:${T.inputBg};color:${T.inputText};transition:border-color .15s,box-shadow .15s;min-width:0}
#vm-in:focus{border-color:${T.accentColor};box-shadow:0 0 0 3px ${T.accentColor}22}
#vm-in::placeholder{color:${dk?'rgba(255,255,255,.35)':'#a1a1aa'}}
#vm-sb{width:38px;height:38px;border-radius:50%;background:${T.accentColor};border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:transform .12s,filter .15s}
#vm-sb:hover{filter:brightness(1.1);transform:scale(1.06)}
#vm-sb:active{transform:scale(.93)}
#vm-sb svg{display:block}
#vm-sb:disabled{opacity:.4;cursor:not-allowed;transform:none}
#vm-bb{width:${bubbleSize};height:${bubbleSize};border-radius:50%;background:${T.bubbleBg};border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 24px rgba(0,0,0,.18);transition:transform .22s cubic-bezier(.34,1.56,.64,1),box-shadow .22s ease;position:relative;flex-shrink:0}
#vm-bb:hover{transform:scale(1.1);box-shadow:0 8px 28px rgba(0,0,0,.22)}
#vm-bb:active{transform:scale(.95)}
#vm-bb svg{transition:transform .22s ease,opacity .18s ease}
#vm-bb.vm-open .vm-ic{transform:scale(0) rotate(-45deg);opacity:0;position:absolute}
#vm-bb.vm-open .vm-ix{transform:scale(1) rotate(0);opacity:1}
#vm-bb:not(.vm-open) .vm-ic{transform:scale(1);opacity:1}
#vm-bb:not(.vm-open) .vm-ix{transform:scale(0) rotate(45deg);opacity:0;position:absolute}
#vm-bg{position:absolute;top:-3px;right:-3px;width:20px;height:20px;background:#ef4444;border-radius:50%;font-size:10px;font-weight:700;color:#fff;display:flex;align-items:center;justify-content:center;opacity:0;transform:scale(0);transition:opacity .2s,transform .2s cubic-bezier(.34,1.56,.64,1);pointer-events:none;border:2px solid #fff}
#vm-bg.vm-show{opacity:1;transform:scale(1)}
#vm-pw{text-align:center;padding:8px 0 10px;font-size:10.5px;color:${dk?'rgba(255,255,255,.35)':'#a1a1aa'};background:${T.poweredBg};flex-shrink:0;border-top:1px solid ${dk?'rgba(255,255,255,.06)':'#f5f5f5'}}
#vm-pw a{color:${T.accentColor};text-decoration:none;font-weight:600}
#vm-pw a:hover{text-decoration:underline}
@media(max-width:480px){#vm-root{bottom:16px;right:16px;left:16px;${align}}#vm-panel{width:100%;max-height:calc(100vh - 100px)}}
${customCSS}`;
    document.head.appendChild(s);
  }

  function buildWidget(){
    var r=document.createElement('div');r.id='vm-root';
    r.innerHTML='<div id="vm-panel" role="dialog" aria-label="Chat with '+botName+'"><div id="vm-header"><div id="vm-av">'+avatarContent+'</div><div id="vm-hi"><div id="vm-hn">'+botName+'</div><div id="vm-hs"><span class="vm-d"></span>Online</div></div><button id="vm-xb" aria-label="Close"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div><div id="vm-ms" role="log" aria-live="polite"></div><div id="vm-ir"><input id="vm-in" type="text" placeholder="'+placeholder+'" autocomplete="off" maxlength="2000"/><button id="vm-sb" aria-label="Send"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M22 2L11 13" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>'+(showPowered?'<div id="vm-pw">Powered by <a href="https://vegamind.qbsglobal.ae" target="_blank" rel="noopener">VegaMind</a></div>':'')+'</div><button id="vm-bb" aria-label="Open chat"><div id="vm-bg">1</div><svg class="vm-ic" width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M21 15c0 .53-.21 1.04-.59 1.41-.37.38-.88.59-1.41.59H7l-4 4V5c0-.53.21-1.04.59-1.41C3.96 3.21 4.47 3 5 3h14c.53 0 1.04.21 1.41.59.38.37.59.88.59 1.41v10z" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><svg class="vm-ix" width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/></svg></button>';
    document.body.appendChild(r);
    if(cfg.openOnLoad)setTimeout(togglePanel,600);
  }

  function $(id){return document.getElementById(id)}
  function togglePanel(){isOpen=!isOpen;$('vm-panel').classList.toggle('vm-open',isOpen);$('vm-bb').classList.toggle('vm-open',isOpen);if(isOpen){hideBadge();setTimeout(function(){$('vm-in').focus()},280)}}
  function showBadge(){if(!isOpen)$('vm-bg').classList.add('vm-show')}
  function hideBadge(){$('vm-bg').classList.remove('vm-show')}
  function addMsg(role,text){var m=$('vm-ms'),d=document.createElement('div');d.className='vm-m '+(role==='assistant'?'vm-b':'vm-u');if(role==='assistant'){d.innerHTML=md(text)}else{d.textContent=text}m.appendChild(d);m.scrollTop=m.scrollHeight;return d}
  function showTyping(){var m=$('vm-ms'),d=document.createElement('div');d.className='vm-t';d.id='vm-ti';d.innerHTML='<span></span><span></span><span></span>';m.appendChild(d);m.scrollTop=m.scrollHeight}
  function hideTyping(){var e=document.getElementById('vm-ti');if(e)e.remove()}

  async function sendMessage(){var inp=$('vm-in'),text=inp.value.trim();if(!text||isTyping)return;inp.value='';isTyping=true;$('vm-sb').disabled=true;addMsg('user',text);showTyping();try{var res=await fetch(SUPABASE_FN+'/widget-chat',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+SUPABASE_ANON},body:JSON.stringify({widget_key:cfg.widgetKey,message:text,session_id:sessionId,visitor_id:visitorId})});var data=await res.json();hideTyping();if(data.reply){sessionId=data.session_id;addMsg('assistant',data.reply);if(!isOpen)showBadge()}else{addMsg('assistant','Sorry, something went wrong. Please try again.')}}catch(err){hideTyping();addMsg('assistant','Connection error. Please check your internet.')}isTyping=false;$('vm-sb').disabled=false;$('vm-in').focus()}

  async function initBot(){try{var res=await fetch(SUPABASE_FN+'/widget-init?key='+encodeURIComponent(cfg.widgetKey),{headers:{'Authorization':'Bearer '+SUPABASE_ANON}});if(!res.ok)return;var data=await res.json();if(data.name&&!cfg.botName)$('vm-hn').textContent=data.name;if(data.welcome_message){addMsg('assistant',data.welcome_message);showBadge()}}catch(e){}}

  function attachEvents(){$('vm-bb').addEventListener('click',togglePanel);$('vm-xb').addEventListener('click',togglePanel);$('vm-sb').addEventListener('click',sendMessage);$('vm-in').addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}})}

  function boot(){injectStyles();buildWidget();attachEvents();initBot()}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
};
